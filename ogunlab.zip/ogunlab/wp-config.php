<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ogunlabstest' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '4yaPLZ0[8)vz[?z$2xv6b0M3_.i|-nth8&CQYiNtPS8dr+ko@y75`zgxmg@Up@;A' );
define( 'SECURE_AUTH_KEY',  '!bW 8<U_G)X|^28{ynpp$w%E)P36(yVd9(^Nz<1.)`A!Nh,zG8F8:6?1@)v!F0A4' );
define( 'LOGGED_IN_KEY',    'g%$J|HE;Egp)0DAT7e`kX6ILPI:h#&&U4SZTu}.umKDgfN.BVDu1/mv!{{:k/id;' );
define( 'NONCE_KEY',        'm<{_uQ?&%cVHx$e_Ct!m}o319-7w69]:8h<n!=+3k~Ho`P3h`1nzo1HguHt%&_$N' );
define( 'AUTH_SALT',        'aw83kLS2^5ktjo#D!EqEB{TzbcjBP[]VY??(wJUsP?VT9_g&soG%~usy,(7V)7_{' );
define( 'SECURE_AUTH_SALT', '!NtQ*XN=Dvtw1BD_q{N-pP~TO~di%;j5_T0E|#ZU52wxhVL*VA!#* Nd(I6@)oU+' );
define( 'LOGGED_IN_SALT',   'JnE= :S[{a}o^3~K5a!CtTvet%?BU)5>kgWlQX3.Hd=hXO-rSaqg FTeS*+:1]Zn' );
define( 'NONCE_SALT',       '2SzD&AcgO+Ge(33b~W/Hm+9V4N3}>F,J=Z0@}`g>qhq+ze[1rs1O0AIH47?|QYd1' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
